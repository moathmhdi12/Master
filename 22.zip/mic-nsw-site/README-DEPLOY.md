# MIC NSW — Ready to Publish

## Status of the pre-launch checklist

| Item | Status |
|---|---|
| Contact form sends real emails | ✅ **Works right now, zero setup** — falls back to opening the visitor's email app pre-filled, until you add a Web3Forms key (then it submits instantly in-page instead) |
| Google Analytics | ✅ **Ready** — snippet added but commented out (needs your real Measurement ID — see below) |
| Pricing | ⚠️ **Still needs your confirmation** — see note below |
| Supplier brands | ⚠️ **Still needs your confirmation** — see note below |
| Logo self-hosted | ⚠️ **Needs a manual step** — see note below (I can't download binary image files from my side) |
| Deployment | ⏳ **Your action** — pick Option A, B or C below |

---

## 1. Contact form — works immediately, upgrade later
Both the homepage contact form and the "Request This Quote" buttons on the Design Studio page (`build-your-renovation.html`) work **right now, with no setup**: submitting opens the visitor's email app with their message (and, on the Design Studio page, their full kitchen/bathroom selections and price estimate) pre-filled to `info@mic-nsw.com.au` — they just hit send.

This is a real fallback, not a placeholder — it works today. The only downside is it opens the visitor's email app instead of submitting silently in the page, and it depends on them having one configured (most people do). To upgrade to a fully silent, one-click submission:
1. Go to **web3forms.com** → enter `info@mic-nsw.com.au` → they instantly email you a free access key. No account/password needed.
2. Paste that key in **two places**, replacing `YOUR_WEB3FORMS_ACCESS_KEY`:
   - `index.html` — the hidden `access_key` input near the contact form
   - `build-your-renovation.html` — the `WEB3FORMS_ACCESS_KEY` constant near the bottom of the script
3. Save both files — the mailto fallback automatically switches off and both forms submit silently from then on.

## 2. Google Analytics — activate in under a minute
1. Create a free GA4 property at **analytics.google.com** → copy your Measurement ID (looks like `G-ABC1234XYZ`).
2. Open `index.html`, find the commented-out block near the top (`<!-- Google Analytics 4 ... -->`), remove the `<!--` and `-->` around it, and replace both instances of `G-XXXXXXXXXX` with your real ID.

## 3. Logo — self-hosting
I wasn't able to download the actual logo image files myself (my tools can only read image *pages*, not save binary image files to disk). Two easy options:
- **Fastest:** right-click each logo on the live site (`mic-nsw.com.au`) → "Save Image As" → save as `logo.png` → upload it into this same folder → then find/replace `https://mic-nsw.com.au/front/images/logo2.png` with `logo.png` (and the same for `logo3.png`) throughout `index.html` and `build-your-renovation.html`.
- **Or:** send me the logo file directly in a message and I'll swap the references for you.

## 4. Pricing & supplier brands
These are the two things I genuinely can't finalise without you — they're business decisions, not technical ones:
- **Pricing**: current figures are grounded in real 2026 Sydney market-rate research, but MIC NSW's *actual* costed rates may differ — confirm before publishing.
- **Suppliers**: brand names shown (Caesarstone, Miele, Reece, etc.) are realistic examples of what's available in Sydney, not confirmed trade accounts — confirm which ones MIC NSW actually sources from.

Tell me the real numbers/brands whenever you have them and I'll update the files immediately.

---

## What's inside this folder
```
index.html                    → Homepage (all sections + Packages + running Estimate bar)
build-your-renovation.html    → Kitchen & Bathroom Design Studio (configurator)
sitemap.xml                   → Submit this to Google Search Console
robots.txt                    → Already configured to allow indexing
```

## How to publish (pick one)

**Option A — Your existing hosting (cPanel / FTP / SiteGround etc.)**
Upload all files in this folder directly into `public_html/` — keep them together in the same folder so the links between the two pages keep working.

**Option B — Netlify / Vercel (drag-and-drop, free, fastest)**
Go to netlify.com → "Add new site" → "Deploy manually" → drag this whole folder in. Live instantly on a temporary URL, then connect your `mic-nsw.com.au` domain in settings.

**Option C — GitHub Pages**
Create a new GitHub repo → upload these files to it → Settings → Pages → set source to the main branch. Free, but slightly more setup than Option B.

**Replacing the current WordPress site:** point your domain's DNS at whichever static host you choose (Option B or C) instead of the WordPress hosting — happy to walk through this step by step if that's the direction you take.
